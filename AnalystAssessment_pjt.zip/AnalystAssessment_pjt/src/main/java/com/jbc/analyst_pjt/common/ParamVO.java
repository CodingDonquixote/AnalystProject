package com.jbc.analyst_pjt.common;

public class ParamVO {
	
	private int p=1; // p
	private int s=10; // s
	private int b=10; // b
	private int m=0; // m
	
	public int getP() {
		return p;
	}
	public void setP(int p) {
		this.p = p;
	}
	public int getS() {
		return s;
	}
	public void setS(int s) {
		this.s = s;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	public int getM() {
		return m;
	}
	public void setM(int m) {
		this.m = m;
	}
	
}
