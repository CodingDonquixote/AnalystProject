CREATE SEQUENCE industry
CREATE TABLE industry(
	industryIdx number(5) PRIMARY KEY,
	industryName varchar2(50) NOT NULL
);