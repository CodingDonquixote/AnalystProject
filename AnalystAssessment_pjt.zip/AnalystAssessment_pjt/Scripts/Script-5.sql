CREATE TABLE member(
	
);